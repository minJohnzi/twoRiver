---
type: knowledge
status: draft
created: 2026-05-14
aliases:
  - Bayesian Classifier
  - 贝叶斯分类器
tags:
  - knowledge
  - machine-learning
  - probability-statistics
  - status/draft
---
# Bayesian Classifier

## Core Idea

Bayesian optimal classifier selects the class with the maximum posterior probability to minimize expected risk. Naive Bayes assumes conditional independence of features to avoid exponential parameter explosion, and Laplace smoothing uses a Dirichlet prior to address the zero-probability problem.

## Explanation

### 1. Bayesian Decision Theory

Given sample $\boldsymbol{x}$, choose class $c$ to minimize conditional risk. Under 0/1 loss, the conditional risk $R(c|\boldsymbol{x}) = 1 - P(c|\boldsymbol{x})$, so the optimal decision is:

$$h^*(\boldsymbol{x}) = \arg\max_{c \in \mathcal{Y}} P(c|\boldsymbol{x})$$

The problem reduces to estimating $P(c|\boldsymbol{x})$. There are two strategies: discriminative (directly modeling $P(c|\boldsymbol{x})$) and generative (indirectly obtained via $P(\boldsymbol{x}|c)P(c)$).

### 2. Naive Bayes

Assuming features are conditionally independent given the class:

$$P(\boldsymbol{x}|c) = \prod_{i=1}^d P(x_i|c)$$

For continuous features, assume $P(x_i|c) \sim \mathcal{N}(\mu_{c,i}, \sigma_{c,i}^2)$, and estimate parameters using MLE:

$$\hat{\mu}_c = \frac{1}{|D_c|}\sum_{\boldsymbol{x}\in D_c} \boldsymbol{x}$$

$$\hat{\boldsymbol{\Sigma}}_c = \frac{1}{|D_c|}\sum_{\boldsymbol{x}\in D_c} (\boldsymbol{x} - \hat{\boldsymbol{\mu}}_c)(\boldsymbol{x} - \hat{\boldsymbol{\mu}}_c)^T$$

Key derivation steps: Expand the MLE objective function using $\boldsymbol{x}^T\mathbf{A}\boldsymbol{x} = \text{tr}(\mathbf{A}\boldsymbol{x}\boldsymbol{x}^T)$, first solve for $\hat{\boldsymbol{\mu}}_c = \bar{\boldsymbol{x}}$ (the mean), then use a positive definite matrix inequality lemma to obtain $\hat{\boldsymbol{\Sigma}}_c = \frac{1}{n}\sum(\boldsymbol{x}_i - \bar{\boldsymbol{x}})(\boldsymbol{x}_i - \bar{\boldsymbol{x}})^T$.

### 3. Laplace Correction

**Problem with MLE**: Feature values that never appear in the training data cause $P(x\_i|c) = 0$, which makes the entire $P(\boldsymbol{x}|c) = 0$.

The correction is equivalent to adding a Dirichlet prior to the estimate:

$$ \hat{P}(c) = \frac{|D\_c| + 1}{|D| + N} $$

where $N$ is the number of classes. This is essentially the posterior expectation under a Dirichlet conjugate prior: likelihood $\propto \prod \theta\_i^{y\_i}$, prior $\propto \prod \theta\_i^{\alpha\_i-1}$, the posterior remains Dirichlet, and the expectation $= \frac{y\_i + \alpha\_i}{\sum(y\_i + \alpha\_i)}$. Setting $\alpha\_i = 1$ yields the Laplace smoothing.

## Key Points

- Under 0/1 loss, the Bayes optimal classifier is equivalent to selecting the class with the maximum posterior probability—the loss function determines the decision rule.  
- The feature independence assumption reduces the number of parameters from $O(|\mathcal{X}| \cdot |\mathcal{Y}|)$ to $O(d \cdot |\mathcal{Y}|)$.  
- In the MLE derivation for Gaussian parameters, the trace trick is used to convert matrix differentiation into scalar optimization.  
- Laplace smoothing is equivalent to the posterior expectation under a Dirichlet($\alpha_i = 1$) prior—the choice of prior has a probabilistic interpretation.  
- The conditional independence assumption rarely holds in practice, but its impact on classification decisions is compensated by maximum likelihood estimation—biased yet sufficient.

## Related

- [[Knowledge_MOC]]
- [[Support_Vector_Machine]]
- [[Linear_Models]]

---

_Source: Pumpkin Book Chapter 7, corresponding to Watermelon Book Chapter 7_