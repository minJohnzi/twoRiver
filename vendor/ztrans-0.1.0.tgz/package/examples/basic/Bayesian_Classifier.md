---
type: knowledge
status: draft
created: 2026-05-14
aliases:
  - Bayesian Classifier
  - 贝叶斯分类器
tags:
  - knowledge
  - machine-learning
  - probability-statistics
  - status/draft
---

# 贝叶斯分类器

## Core Idea
贝叶斯最优分类器选择后验概率最大的类别以最小化期望风险。朴素贝叶斯假设特征条件独立以规避指数级参数爆炸，拉普拉斯修正用 Dirichlet 先验解决零概率问题。

## Explanation

### 1. 贝叶斯决策论

给定样本 $\boldsymbol{x}$，选择类别 $c$ 使条件风险最小。在 0/1 损失下，条件风险 $R(c|\boldsymbol{x}) = 1 - P(c|\boldsymbol{x})$，因此最优决策为：

$$h^*(\boldsymbol{x}) = \arg\max_{c \in \mathcal{Y}} P(c|\boldsymbol{x})$$

问题转化为估计 $P(c|\boldsymbol{x})$。有两种策略：判别式（直接建模 $P(c|\boldsymbol{x})$）和生成式（通过 $P(\boldsymbol{x}|c)P(c)$ 间接求得）。

### 2. 朴素贝叶斯

假设特征在给定类别下条件独立：

$$P(\boldsymbol{x}|c) = \prod_{i=1}^d P(x_i|c)$$

对于连续特征，假设 $P(x_i|c) \sim \mathcal{N}(\mu_{c,i}, \sigma_{c,i}^2)$，用 MLE 估计参数：

$$\hat{\mu}_c = \frac{1}{|D_c|}\sum_{\boldsymbol{x}\in D_c} \boldsymbol{x}$$

$$\hat{\boldsymbol{\Sigma}}_c = \frac{1}{|D_c|}\sum_{\boldsymbol{x}\in D_c} (\boldsymbol{x} - \hat{\boldsymbol{\mu}}_c)(\boldsymbol{x} - \hat{\boldsymbol{\mu}}_c)^T$$

推导关键：将 MLE 目标函数通过 $\boldsymbol{x}^T\mathbf{A}\boldsymbol{x} = \text{tr}(\mathbf{A}\boldsymbol{x}\boldsymbol{x}^T)$ 展开，先解得 $\hat{\boldsymbol{\mu}}_c = \bar{\boldsymbol{x}}$（均值），再通过一个正定矩阵不等式引理解得 $\hat{\boldsymbol{\Sigma}}_c = \frac{1}{n}\sum(\boldsymbol{x}_i - \bar{\boldsymbol{x}})(\boldsymbol{x}_i - \bar{\boldsymbol{x}})^T$。

### 3. 拉普拉斯修正

MLE 的问题：未出现的特征取值会使 $P(x_i|c) = 0$，导致整个 $P(\boldsymbol{x}|c) = 0$。

修正方案等价于给先验加上 Dirichlet 分布：

$$\hat{P}(c) = \frac{|D_c| + 1}{|D| + N}$$

其中 $N$ 为类别数。本质是 Dirichlet 共轭先验下的后验期望估计：似然 $\propto \prod \theta_i^{y_i}$，先验 $\propto \prod \theta_i^{\alpha_i-1}$，后验仍为 Dirichlet，期望 $= \frac{y_i + \alpha_i}{\sum(y_i + \alpha_i)}$。令 $\alpha_i = 1$ 即得拉普拉斯修正。

## Key Points

- 贝叶斯最优分类器在 0/1 损失下等价于选择后验最大类别——损失函数决定决策形式
- 特征独立假设使参数数量从 $O(|\mathcal{X}| \cdot |\mathcal{Y}|)$ 降为 $O(d \cdot |\mathcal{Y}|)$
- 高斯参数 MLE 推导中利用了迹技巧将矩阵求导转化为标量优化
- 拉普拉斯修正等价于 Dirichlet($\alpha_i = 1$) 先验下的后验期望——先验选择有概率解释
- 条件独立假设在实际中几乎不成立，但对分类决策的影响被极大似然补偿——有偏但够用

## Related
- [[Knowledge_MOC]]
- [[Support_Vector_Machine]]
- [[Linear_Models]]

---

*来源: 南瓜书 Chapter 7, 对应西瓜书第 7 章*
