---
type: knowledge
created: 2026-05-29
aliases:
  - Tauri教程
  - Tauri v2入门
tags:
  - knowledge
  - rust
  - tauri
  - tutorial
  - desktop-app
---
# Complete Tauri v2 Development Tutorial

> Reference: <https://v2.tauri.app/start/prerequisites/>

## 1. Environment Setup

Tauri requires three types of dependencies: system-level toolchain, Rust, and Node.js (optional, only needed for the web frontend).

### 1.1 Windows

**Microsoft C++ Build Tools**

Get the installer from the [Visual Studio Downloads page](https://visualstudio.microsoft.com/downloads/), and select the "Desktop development with C++" workload. After installation, verify:

```powershell
# Confirm cl.exe is available (in Developer PowerShell)
cl
```

**WebView2**

Windows 10 (1803+) and Windows 11 come with WebView2 pre-installed. For older systems, download the [WebView2 Evergreen Standalone Installer](https://developer.microsoft.com/en-us/microsoft-edge/webview2/).

Verify WebView2 is present:

```powershell
# Check the registry
Get-ItemProperty HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5} | Select-Object -Property location
```

### 1.2 macOS

```bash
# Minimal installation (desktop development only)
xcode-select --install

# Or install full Xcode (for mobile/iOS development)
# Get it from the App Store or developer.apple.com
# Be sure to launch Xcode once after installation to complete initialization
```

### 1.3 Linux

**Debian/Ubuntu:**

```bash
sudo apt update
sudo apt install libwebkit2gtk-4.1-dev build-essential curl wget file \
  libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev
```

**Arch Linux:**

```bash
sudo pacman -Syu
sudo pacman -S --needed webkit2gtk-4.1 base-devel curl wget file \
  openssl appmenu-gtk-module libappindicator-gtk3 librsvg xdotool
```

**Fedora:**

```bash
sudo dnf check-update
sudo dnf install webkit2gtk4.1-devel openssl-devel curl wget file \
  libappindicator-gtk3-devel librsvg2-devel libxdo-devel
sudo dnf group install "c-development"
```

**openSUSE:**

```bash
sudo zypper up
sudo zypper in webkit2gtk3-devel libopenssl-devel curl wget file \
  libappindicator3-1 librsvg-devel
sudo zypper in -t pattern devel_basis
```

**Alpine:**

```bash
sudo apk add build-base webkit2gtk curl wget file openssl \
  libayatana-appindicator-dev librsvg
```

**NixOS** users refer to [NixOS Wiki](https://wiki.nixos.org/wiki/Tauri).

---

## 2. Rust Installation

Tauri's runtime is entirely built with Rust, which is the only hard dependency.

### 2.1 Installing rustup

**Linux / macOS:**

```bash
curl --proto '=https' --tlsv1.2 https://sh.rustup.rs -sSf | sh
```

**Windows:**

```powershell
winget install --id Rustlang.Rustup
```

### 2.2 Switch to the MSVC Toolchain (Required on Windows)

```powershell
rustup default stable-msvc
```

Linux/macOS can use the default GNU toolchain without any additional steps.

### 2.3 Verify Installation

```bash
rustc --version   # Should output rustc x.y.z (......)
cargo --version   # Should output cargo x.y.z (......)
```

After installation, be sure to restart the terminal for the environment variables to take effect.

---

## 3. Node.js (Optional)

Only needed when using JS frontend frameworks like React/Vue/Svelte. Download the LTS version from [nodejs.org](https://nodejs.org).

```bash
node -v   # Should output v20.x.x or v22.x.x
npm -v    # Should output 10.x.x
```

Optional package managers:

```bash
corepack enable          # Enable pnpm / yarn
pnpm -v                  # Verify pnpm
```

---

## 4. Creating a Project

There are two ways: create with a single command using scaffolding (recommended), or manually add to an existing frontend project.

### 4.1 Scaffolding with create-tauri-app

Choose a method to run:

| Environment | Command                                                              |
| ----------- | -------------------------------------------------------------------- |
| Bash        | `sh <(curl https://create.tauri.app/sh)`                             |
| PowerShell  | `irm https://create.tauri.app/ps \| iex`                             |
| npm         | `npm create tauri-app@latest`                                        |
| pnpm        | `pnpm create tauri-app`                                              |
| yarn        | `yarn create tauri-app`                                              |
| bun         | `bun create tauri-app`                                               |
| deno        | `deno run -A npm:create-tauri-app`                                   |
| Cargo       | `cargo install create-tauri-app --locked && cargo create-tauri-app`  |

**Interactive options:**

1. **Project name** — Project name, default `tauri-app`
2. **Identifier** — Application identifier (reverse domain format), default `com.tauri-app.app`
3. **Frontend language** — Choose one of three:
   - **TypeScript / JavaScript** → Templates: Vanilla / Vue / Svelte / React / Solid / Angular / Preact
   - **Rust (cargo)** → Templates: Vanilla / Yew / Leptos / Sycamore
   - **.NET (dotnet)** → Templates: Blazor
4. **Package manager** (TS/JS path) — pnpm / yarn / npm / bun
5. **UI style** (TS/JS path) — TypeScript or JavaScript

**Recommended for beginners:** Language TypeScript/JavaScript + Package manager pnpm + Template Vanilla + Style TypeScript.

**Start the development server:**

```bash
# pnpm (recommended)
cd tauri-app && pnpm install && pnpm tauri dev

# npm
cd tauri-app && npm install && npm run tauri dev

# cargo (Rust frontend)
cd tauri-app && cargo tauri dev
```

The first run compiles all Rust dependencies (takes a few minutes); subsequent runs only recompile the project code.

### 4.2 Manually Adding to an Existing Project

**Step 1 — Create the frontend project** (using Vite as an example):

```bash
mkdir tauri-app && cd tauri-app
pnpm create vite .   # Select Vanilla + TypeScript
```

**Step 2 — Install Tauri CLI:**

```bash
pnpm add -D @tauri-apps/cli@latest
```

**Step 3 — Initialize Tauri:**

```bash
pnpm tauri init
```

Interactive prompts:

- App name: Application name
- Window title: Window title
- Web assets location: Default `..` (relative path to src-tauri)
- Dev server URL: Default `http://localhost:5173` (Vite's default port)
- Frontend dev command: `pnpm dev`
- Frontend build command: `pnpm build`

After completion, the `src-tauri/` directory will be generated in the project root.

**Step 4 — Start:**

```bash
pnpm tauri dev
```

---

## 5. Project Structure

Typical directory layout after initialization:

```
tauri-app/
├── src/                    # Frontend source (Vite project)
│   ├── main.ts
│   ├── App.vue / App.tsx   # Depends on framework
│   └── ...
├── src-tauri/              # Tauri Rust backend
│   ├── src/
│   │   ├── main.rs         # Rust entry point, #[tauri::command] goes here
│   │   └── lib.rs          # Library root (can split into modules)
│   ├── icons/              # App icons (auto-generated)
│   ├── tauri.conf.json     # Core configuration (window/permissions/packaging)
│   ├── Cargo.toml          # Rust dependency declarations
│   └── capabilities/       # v2 permission tokens (per-window authorization)
│       └── default.json
├── package.json            # Frontend dependencies
└── vite.config.ts          # Frontend build configuration
```

### Key File Descriptions

**`tauri.conf.json`** — Main application configuration:

```json
{
  "productName": "my-app",
  "version": "0.1.0",
  "identifier": "com.myapp.dev",
  "build": {
    "frontendDist": "../dist",
    "devUrl": "http://localhost:5173",
    "beforeDevCommand": "pnpm dev",
    "beforeBuildCommand": "pnpm build"
  },
  "app": {
    "windows": [
      {
        "title": "My App",
        "width": 800,
        "height": 600
      }
    ],
    "security": {
      "csp": null
    }
  }
}
```

**`capabilities/default.json`** — v2 permission token:

```json
{
  "$schema": "../gen/schemas/desktop-schema.json",
  "identifier": "default",
  "description": "Default permission set",
  "windows": ["main"],
  "permissions": [
    "core:default"
  ]
}
```

---

## 6. Development Workflow

### 6.1 Starting Development Mode

```bash
# Desktop
pnpm tauri dev

# Mobile
pnpm tauri android dev
pnpm tauri ios dev       # macOS only
```

The first run compiles slowly (full Rust dependency build), subsequent runs use incremental compilation only.

### 6.2 Dev Server Mode

**Option A — Framework's built-in dev server (recommended):** Started by Vite/Next.js etc., Tauri connects to the address specified in `devUrl`. Configured via `build.devUrl` and `build.beforeDevCommand` in `tauri.conf.json`.

**Option B — Tauri's built-in dev server:** When not relying on a frontend bundler, point `frontendDist` to the source directory (must contain `index.html`), and the Tauri CLI will serve static files on its own. Note: The built-in server does not support encryption; do not use it on untrusted networks.

### 6.3 Hot Reload

- **Frontend hot update** — Provided by the frontend toolchain (Vite/Webpack), the WebView auto-refreshes like a browser  
- **Rust hot reload** — Tauri watches `.rs` files under `src-tauri/`, automatically recompiles and restarts the app on changes  

Disable Rust watching:  

```bash  
pnpm tauri dev --no-watch  
```  

Create a `.taurignore` file under `src-tauri/` to exclude specific files:  

```  
# .taurignore — syntax same as .gitignore  
src-tauri/tests/  
```

### 6.4 Debugging

**Desktop Web Inspector:**

Right-click on the application window → Inspect, or use the shortcut:

- Windows/Linux: `Ctrl + Shift + I`
- macOS: `Cmd + Option + I`

**Android Debugging:**

1. Enable Developer Mode on the device (tap the build number 7 times), then enable USB debugging
2. Visit `chrome://inspect` in Chrome
3. Find your device in the remote device list and click **Inspect**

**iOS Debugging (requires macOS):**

1. Safari → Settings → Advanced → Check "Show Develop menu in menu bar"
2. Physical device: Settings → Safari → Advanced → Enable Web Inspector
3. Safari → Develop menu → Select the device and localhost

---

## 7. Frontend-Backend Communication

### 7.1 Defining Rust Commands

```rust
// src-tauri/src/main.rs
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! From Rust.", name)
}

#[tauri::command]
fn read_config(path: String) -> Result<String, String> {
    std::fs::read_to_string(&path).map_err(|e| e.to_string())
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![greet, read_config])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

### 7.2 Frontend Invocation

```typescript
import { invoke } from '@tauri-apps/api/core';

// Simple invocation
const msg = await invoke<string>('greet', { name: 'World' });
console.log(msg); // "Hello, World! From Rust."

// With error handling
try {
  const config = await invoke<string>('read_config', {
    path: '/etc/app/config.toml'
  });
} catch (e) {
  console.error('Read failed:', e);
}
```

### 7.3 Event Push (Rust → Frontend)

```rust
// Rust side: emit event
use tauri::Emitter;

#[tauri::command]
fn start_task(app: tauri::AppHandle) {
    std::thread::spawn(move || {
        app.emit("task-progress", 50).unwrap();
    });
}
```

```typescript
// Frontend: listen for event
import { listen } from '@tauri-apps/api/event';

const unlisten = await listen<number>('task-progress', (event) => {
    console.log(`Progress: ${event.payload}%`);
});
```

---

## 8. Build & Package

### 8.1 Desktop

```bash
pnpm tauri build
```

Output locations:

| Platform | Output |
| -------- | ------ |
| Windows | `src-tauri/target/release/bundle/msi/*.msi` + `nsis/*.exe` |
| macOS | `src-tauri/target/release/bundle/dmg/*.dmg` + `macOS/*.app` |
| Linux | `src-tauri/target/release/bundle/deb/*.deb` + `AppImage/*.AppImage` |

### 8.2 Mobile

```bash
# Android
pnpm tauri android build

# iOS
pnpm tauri ios build
```

### 8.3 Build Optimization

**Reducing Binary Size:**

```toml
# Cargo.toml
[profile.release]
strip = true
lto = true
codegen-units = 1
opt-level = "s"     # Optimize for size
# opt-level = 3     # Optimize for performance (default)
```

**Customizing App Icon:**

```bash
# Place a 1024x1024 PNG in src-tauri/icons/, then run:
pnpm tauri icon ./app-icon.png
```

---

## 9. Plugin Installation

All functionalities in Tauri v2 are provided as plugins, which can be added on demand:

```bash
# File system
pnpm tauri add fs

# Native dialogs
pnpm tauri add dialog

# Clipboard
pnpm tauri add clipboard

# System notifications
pnpm tauri add notification

# Shell (execute external commands)
pnpm tauri add shell

# Auto-updater
pnpm tauri add updater

# Persistent storage
pnpm tauri add store
```

After installing each plugin, the corresponding permissions are automatically appended to `capabilities/default.json`.

---

## 10. Frequently Asked Questions

### Rust environment variables not taking effect

```bash
# Restart terminal or manually source
source "$HOME/.cargo/env"    # Linux/macOS
# Windows: Restart terminal
```

### Windows: Error: linker `link.exe` not found

Indicates that the MSVC toolchain is not installed:

```powershell
rustup default stable-msvc
# Confirm that Visual Studio C++ build tools are installed
```

### Linux: Error `webkit2gtk-4.1` not found

The distribution does not have the WebKit development package installed. Refer to Section 1.3 to install the corresponding dependencies.

### macOS: Error `xcrun: error`

Xcode command line tools are not installed or not fully initialized:

```bash
xcode-select --install
# If already installed, try resetting
sudo xcode-select --reset
```

### First Build Extremely Slow

All Rust dependencies (including WebKit bindings) are fully compiled during the first build. Subsequent incremental and release builds will be much faster. You can also set up a domestic mirror to speed things up:

```bash
# ~/.cargo/config.toml
[source.crates-io]
replace-with = 'ustc'

[source.ustc]
registry = "sparse+https://mirrors.ustc.edu.cn/crates.io-index/"
```

### Frontend dev server port is occupied

Modify `build.devUrl` in `tauri.conf.json`, and synchronously update the port configuration of the frontend build tool.

### Application Window Blank

Check whether the `build.frontendDist` path correctly points to the frontend build output directory (usually `../dist`), and whether `beforeBuildCommand` correctly executes the frontend build.

---

## Related

- [[Knowledge_MOC]]
- [[Tauri Overview]]
- [[Rust Learning]]
- [[C to Rust Mental Model Comparison]]