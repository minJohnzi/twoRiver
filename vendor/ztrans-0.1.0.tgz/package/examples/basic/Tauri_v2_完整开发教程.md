---
type: knowledge
created: 2026-05-29
aliases:
  - Tauri教程
  - Tauri v2入门
tags:
  - knowledge
  - rust
  - tauri
  - tutorial
  - desktop-app
---

# Tauri v2 完整开发教程

> 参考: https://v2.tauri.app/zh-cn/start/prerequisites/

## 一、环境配置

Tauri 需要三类依赖：系统级工具链、Rust、以及 Node.js（可选，仅 Web 前端需要）。

### 1.1 Windows

**Microsoft C++ 生成工具**

从 [Visual Studio 下载页](https://visualstudio.microsoft.com/downloads/) 获取安装程序，勾选"使用 C++ 的桌面开发"工作负载。安装后验证：

```powershell
# 确认 cl.exe 可用（在 Developer PowerShell 中）
cl
```

**WebView2**

Windows 10（1803+）和 Windows 11 已预装。旧版系统需下载 [WebView2 常青独立安装程序](https://developer.microsoft.com/en-us/microsoft-edge/webview2/)。

验证 WebView2 存在：

```powershell
# 检查注册表
Get-ItemProperty HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5} | Select-Object -Property location
```

### 1.2 macOS

```bash
# 最小安装（仅桌面开发）
xcode-select --install

# 或安装完整 Xcode（需移动端/iOS 开发时）
# 从 App Store 或 developer.apple.com 获取
# 安装后务必启动一次 Xcode 完成初始化
```

### 1.3 Linux

**Debian/Ubuntu：**

```bash
sudo apt update
sudo apt install libwebkit2gtk-4.1-dev build-essential curl wget file \
  libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev
```

**Arch Linux：**

```bash
sudo pacman -Syu
sudo pacman -S --needed webkit2gtk-4.1 base-devel curl wget file \
  openssl appmenu-gtk-module libappindicator-gtk3 librsvg xdotool
```

**Fedora：**

```bash
sudo dnf check-update
sudo dnf install webkit2gtk4.1-devel openssl-devel curl wget file \
  libappindicator-gtk3-devel librsvg2-devel libxdo-devel
sudo dnf group install "c-development"
```

**openSUSE：**

```bash
sudo zypper up
sudo zypper in webkit2gtk3-devel libopenssl-devel curl wget file \
  libappindicator3-1 librsvg-devel
sudo zypper in -t pattern devel_basis
```

**Alpine：**

```bash
sudo apk add build-base webkit2gtk curl wget file openssl \
  libayatana-appindicator-dev librsvg
```

**NixOS** 用户参考 [NixOS Wiki](https://wiki.nixos.org/wiki/Tauri)。

---

## 二、Rust 安装

Tauri 的运行时完全由 Rust 构建，这是唯一的硬性依赖。

### 2.1 安装 rustup

**Linux / macOS：**

```bash
curl --proto '=https' --tlsv1.2 https://sh.rustup.rs -sSf | sh
```

**Windows：**

```powershell
winget install --id Rustlang.Rustup
```

### 2.2 切换到 MSVC 工具链（Windows 必须）

```powershell
rustup default stable-msvc
```

Linux/macOS 用默认的 GNU 工具链即可，无需额外操作。

### 2.3 验证安装

```bash
rustc --version   # 应输出 rustc x.y.z (......)
cargo --version   # 应输出 cargo x.y.z (......)
```

安装后务必重启终端使环境变量生效。

---

## 三、Node.js（可选）

仅当使用 React/Vue/Svelte 等 JS 前端框架时需要。从 [nodejs.org](https://nodejs.org) 下载 LTS 版本。

```bash
node -v   # 应输出 v20.x.x 或 v22.x.x
npm -v    # 应输出 10.x.x
```

可选包管理器：

```bash
corepack enable          # 启用 pnpm / yarn
pnpm -v                  # 验证 pnpm
```

---

## 四、创建项目

有两种方式：脚手架一键创建（推荐），或手动添加到已有前端项目。

### 4.1 脚手架创建（create-tauri-app）

选择一种运行方式：

| 环境 | 命令 |
|------|------|
| Bash | `sh <(curl https://create.tauri.app/sh)` |
| PowerShell | `irm https://create.tauri.app/ps \| iex` |
| npm | `npm create tauri-app@latest` |
| pnpm | `pnpm create tauri-app` |
| yarn | `yarn create tauri-app` |
| bun | `bun create tauri-app` |
| deno | `deno run -A npm:create-tauri-app` |
| Cargo | `cargo install create-tauri-app --locked && cargo create-tauri-app` |

**交互选项：**

1. **Project name** — 项目名，默认 `tauri-app`
2. **Identifier** — 应用标识符（反域名格式），默认 `com.tauri-app.app`
3. **前端语言** — 三选一：
   - **TypeScript / JavaScript** → 模板: Vanilla / Vue / Svelte / React / Solid / Angular / Preact
   - **Rust (cargo)** → 模板: Vanilla / Yew / Leptos / Sycamore
   - **.NET (dotnet)** → 模板: Blazor
4. **包管理器**（TS/JS 路径）— pnpm / yarn / npm / bun
5. **UI 风格**（TS/JS 路径）— TypeScript 或 JavaScript

**推荐给初学者的选择：** 语言 TypeScript/JavaScript + 包管理器 pnpm + 模板 Vanilla + 风格 TypeScript。

**启动开发服务器：**

```bash
# pnpm（推荐）
cd tauri-app && pnpm install && pnpm tauri dev

# npm
cd tauri-app && npm install && npm run tauri dev

# cargo（Rust 前端）
cd tauri-app && cargo tauri dev
```

首次运行会编译所有 Rust 依赖（需要几分钟），后续只重编译项目代码。

### 4.2 手动添加到已有项目

**步骤 1 — 创建前端项目**（以 Vite 为例）：

```bash
mkdir tauri-app && cd tauri-app
pnpm create vite .   # 选 Vanilla + TypeScript
```

**步骤 2 — 安装 Tauri CLI：**

```bash
pnpm add -D @tauri-apps/cli@latest
```

**步骤 3 — 初始化 Tauri：**

```bash
pnpm tauri init
```

交互提示：
- App name: 应用名称
- Window title: 窗口标题
- Web assets 位置: 默认 `..`（相对 src-tauri 的路径）
- Dev server URL: 默认 `http://localhost:5173`（Vite 的默认端口）
- Frontend dev command: `pnpm dev`
- Frontend build command: `pnpm build`

完成后项目根目录下会生成 `src-tauri/` 目录。

**步骤 4 — 启动：**

```bash
pnpm tauri dev
```

---

## 五、项目结构

初始化后的典型目录布局：

```
tauri-app/
├── src/                    # 前端源码（Vite 项目）
│   ├── main.ts
│   ├── App.vue / App.tsx   # 取决于框架
│   └── ...
├── src-tauri/              # Tauri Rust 后端
│   ├── src/
│   │   ├── main.rs         # Rust 入口，#[tauri::command] 写这里
│   │   └── lib.rs          # 库根（可拆分模块）
│   ├── icons/              # 应用图标（自动生成）
│   ├── tauri.conf.json     # 核心配置（窗口/权限/打包）
│   ├── Cargo.toml          # Rust 依赖声明
│   └── capabilities/       # v2 权限令牌（按窗口授权）
│       └── default.json
├── package.json            # 前端依赖
└── vite.config.ts          # 前端构建配置
```

### 关键文件说明

**`tauri.conf.json`** — 应用主配置：

```json
{
  "productName": "my-app",
  "version": "0.1.0",
  "identifier": "com.myapp.dev",
  "build": {
    "frontendDist": "../dist",
    "devUrl": "http://localhost:5173",
    "beforeDevCommand": "pnpm dev",
    "beforeBuildCommand": "pnpm build"
  },
  "app": {
    "windows": [
      {
        "title": "My App",
        "width": 800,
        "height": 600
      }
    ],
    "security": {
      "csp": null
    }
  }
}
```

**`capabilities/default.json`** — v2 权限令牌：

```json
{
  "$schema": "../gen/schemas/desktop-schema.json",
  "identifier": "default",
  "description": "默认权限集",
  "windows": ["main"],
  "permissions": [
    "core:default"
  ]
}
```

---

## 六、开发工作流

### 6.1 启动开发模式

```bash
# 桌面端
pnpm tauri dev

# 移动端
pnpm tauri android dev
pnpm tauri ios dev       # 仅 macOS
```

首次运行编译慢（Rust 依赖全量构建），后续仅增量编译。

### 6.2 Dev Server 模式

**方案 A — 框架自带 dev server（推荐）：** 由 Vite/Next.js 等自行启动，Tauri 连接到 `devUrl` 指定的地址。配置在 `tauri.conf.json` 的 `build.devUrl` 和 `build.beforeDevCommand`。

**方案 B — Tauri 内置 dev server：** 不依赖前端打包器时，将 `frontendDist` 指向源码目录（须含 `index.html`），Tauri CLI 自行托管静态文件。注意：内置服务器不支持加密，不要在不可信网络中使用。

### 6.3 热重载

- **前端热更新** — 由前端工具链（Vite/Webpack）提供，WebView 像浏览器一样自动刷新
- **Rust 热重载** — Tauri 监视 `src-tauri/` 下的 `.rs` 文件，变更后自动重新编译并重启应用

禁用 Rust 监视：

```bash
pnpm tauri dev --no-watch
```

在 `src-tauri/` 下创建 `.taurignore` 文件可排除特定文件：

```
# .taurignore — 语法同 .gitignore
src-tauri/tests/
```

### 6.4 调试

**桌面端 Web Inspector：**

在应用窗口右键 → Inspect，或快捷键：
- Windows/Linux: `Ctrl + Shift + I`
- macOS: `Cmd + Option + I`

**Android 调试：**

1. 设备开启开发者模式（连点版本号 7 次），再开启 USB 调试
2. Chrome 访问 `chrome://inspect`
3. 在远程设备列表找到你的设备，点击 **检查**

**iOS 调试（需 macOS）：**

1. Safari → 设置 → 高级 → 勾选"在菜单栏中显示开发功能"
2. 物理设备：设置 → Safari → 高级 → 开启 Web Inspector
3. Safari → Develop 菜单 → 选择设备和 localhost

---

## 七、前后端通信

### 7.1 定义 Rust 命令

```rust
// src-tauri/src/main.rs
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! From Rust.", name)
}

#[tauri::command]
fn read_config(path: String) -> Result<String, String> {
    std::fs::read_to_string(&path).map_err(|e| e.to_string())
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![greet, read_config])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

### 7.2 前端调用

```typescript
import { invoke } from '@tauri-apps/api/core';

// 简单调用
const msg = await invoke<string>('greet', { name: 'World' });
console.log(msg); // "Hello, World! From Rust."

// 带错误处理
try {
  const config = await invoke<string>('read_config', {
    path: '/etc/app/config.toml'
  });
} catch (e) {
  console.error('读取失败:', e);
}
```

### 7.3 事件推送（Rust → 前端）

```rust
// Rust 端推送事件
use tauri::Emitter;

#[tauri::command]
fn start_task(app: tauri::AppHandle) {
    std::thread::spawn(move || {
        app.emit("task-progress", 50).unwrap();
    });
}
```

```typescript
// 前端监听事件
import { listen } from '@tauri-apps/api/event';

const unlisten = await listen<number>('task-progress', (event) => {
    console.log(`进度: ${event.payload}%`);
});
```

---

## 八、构建打包

### 8.1 桌面端

```bash
pnpm tauri build
```

产物位置：

| 平台 | 产物 |
|------|------|
| Windows | `src-tauri/target/release/bundle/msi/*.msi` + `nsis/*.exe` |
| macOS | `src-tauri/target/release/bundle/dmg/*.dmg` + `macOS/*.app` |
| Linux | `src-tauri/target/release/bundle/deb/*.deb` + `AppImage/*.AppImage` |

### 8.2 移动端

```bash
# Android
pnpm tauri android build

# iOS
pnpm tauri ios build
```

### 8.3 构建优化

**减小二进制体积：**

```toml
# Cargo.toml
[profile.release]
strip = true
lto = true
codegen-units = 1
opt-level = "s"     # 优化体积
# opt-level = 3     # 优化性能（默认）
```

**自定义应用图标：**

```bash
# 将 1024x1024 PNG 放到 src-tauri/icons/，运行：
pnpm tauri icon ./app-icon.png
```

---

## 九、插件安装

Tauri v2 所有功能以插件形式提供，按需添加：

```bash
# 文件系统
pnpm tauri add fs

# 原生对话框
pnpm tauri add dialog

# 剪贴板
pnpm tauri add clipboard

# 系统通知
pnpm tauri add notification

# Shell（执行外部命令）
pnpm tauri add shell

# 自动更新
pnpm tauri add updater

# 持久化存储
pnpm tauri add store
```

每个插件安装后会在 `capabilities/default.json` 中自动追加对应权限。

---

## 十、常见问题

### Rust 环境变量不生效

```bash
# 重启终端或手动 source
source "$HOME/.cargo/env"    # Linux/macOS
# Windows: 重启终端
```

### Windows: 报错 linker `link.exe` not found

表示未安装 MSVC 工具链：

```powershell
rustup default stable-msvc
# 确认已安装 Visual Studio C++ 生成工具
```

### Linux: 报错 `webkit2gtk-4.1` not found

发行版未安装 WebKit 开发包，对照 1.3 节安装对应依赖。

### macOS: 报错 `xcrun: error`

Xcode 命令行工具未安装或未完成初始化：

```bash
xcode-select --install
# 如已安装，尝试重置
sudo xcode-select --reset
```

### 首次构建极慢

所有 Rust 依赖（包括 WebKit 绑定）在首次构建时全量编译。后续增量和 release 构建会快很多。也可以设置国内镜像加速：

```bash
# ~/.cargo/config.toml
[source.crates-io]
replace-with = 'ustc'

[source.ustc]
registry = "sparse+https://mirrors.ustc.edu.cn/crates.io-index/"
```

### 前端 dev server 端口被占用

修改 `tauri.conf.json` 中的 `build.devUrl`，并同步修改前端构建工具的端口配置。

### 应用窗口空白

检查 `build.frontendDist` 路径是否正确指向前端构建产物目录（通常是 `../dist`），`beforeBuildCommand` 是否正确执行了前端构建。

---

## Related
- [[Knowledge_MOC]]
- [[Tauri概览]]
- [[Rust学习]]
- [[C到Rust心智模型对照]]
